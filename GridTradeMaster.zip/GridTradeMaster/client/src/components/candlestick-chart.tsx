import { useEffect, useRef, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import type { GridStrategy } from "@shared/schema";

interface CandlestickChartProps {
  symbol: string;
  gridStrategy?: GridStrategy;
}

interface CandleData {
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export function CandlestickChart({ symbol, gridStrategy }: CandlestickChartProps) {
  const [interval, setInterval] = useState('1m');
  const [currentPrice, setCurrentPrice] = useState(0);

  // Fetch candlestick data
  const { data: candlestickData } = useQuery<CandleData[]>({
    queryKey: ['/api/candlestick', symbol, interval],
    refetchInterval: 10000,
  });

  useEffect(() => {
    if (candlestickData && candlestickData.length > 0) {
      setCurrentPrice(candlestickData[candlestickData.length - 1].close);
    }
  }, [candlestickData]);

  const intervals = [
    { value: '1m', label: '1 Minute' },
    { value: '5m', label: '5 Minutes' },
    { value: '15m', label: '15 Minutes' },
    { value: '1h', label: '1 Hour' },
    { value: '4h', label: '4 Hours' },
    { value: '1d', label: '1 Day' },
  ];

  return (
    <Card className="bg-surface border-gray-800">
      <CardHeader className="border-b border-gray-800">
        <div className="flex items-center justify-between">
          <CardTitle className="font-semibold">{symbol} Chart</CardTitle>
          <div className="flex items-center space-x-2">
            <Select value={interval} onValueChange={setInterval}>
              <SelectTrigger className="w-32 bg-gray-800 border-gray-700 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {intervals.map((int) => (
                  <SelectItem key={int.value} value={int.value}>
                    {int.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div ref={chartContainerRef} className="w-full" />
        {gridStrategy && (
          <div className="mt-4 text-xs text-gray-400 space-y-1">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-0.5 bg-orange-500"></div>
                <span>Grid Range</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-0.5 bg-blue-500"></div>
                <span>Current Price</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-0.5 bg-gray-600" style={{ borderStyle: 'dotted' }}></div>
                <span>Grid Levels</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}