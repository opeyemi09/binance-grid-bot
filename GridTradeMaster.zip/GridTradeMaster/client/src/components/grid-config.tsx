import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertGridStrategySchema } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

const formSchema = insertGridStrategySchema.extend({
  symbol: z.string().min(1, "Please select a trading pair"),
});

type FormData = z.infer<typeof formSchema>;

export function GridConfig() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      symbol: "",
      status: "active",
      lowerPrice: 0,
      upperPrice: 0,
      gridLevels: 50,
      investmentAmount: 1000,
      totalOrders: 50,
    }
  });

  const createGridMutation = useMutation({
    mutationFn: async (data: FormData) => {
      const response = await apiRequest('POST', '/api/strategies', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/strategies/1'] });
      toast({
        title: "Grid Strategy Created",
        description: "Your new grid strategy has been created successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create grid strategy. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: FormData) => {
    createGridMutation.mutate(data);
  };

  const tradingPairs = [
    { value: "BTC/USDT", label: "BTC/USDT" },
    { value: "ETH/USDT", label: "ETH/USDT" },
    { value: "SOL/USDT", label: "SOL/USDT" },
    { value: "ADA/USDT", label: "ADA/USDT" },
  ];

  return (
    <Card className="bg-surface border-gray-800">
      <CardHeader className="border-b border-gray-800">
        <CardTitle className="font-semibold">Quick Grid Setup</CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="symbol" className="text-sm font-medium text-gray-400 mb-2 block">
              Trading Pair
            </Label>
            <Select onValueChange={(value) => setValue("symbol", value)}>
              <SelectTrigger className="w-full bg-gray-800 border-gray-700 text-white">
                <SelectValue placeholder="Select trading pair" />
              </SelectTrigger>
              <SelectContent>
                {tradingPairs.map((pair) => (
                  <SelectItem key={pair.value} value={pair.value}>
                    {pair.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.symbol && (
              <p className="text-error text-xs mt-1">{errors.symbol.message}</p>
            )}
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="lowerPrice" className="text-sm font-medium text-gray-400 mb-2 block">
                Lower Price
              </Label>
              <Input
                id="lowerPrice"
                type="number"
                step="0.01"
                placeholder="40,000"
                className="bg-gray-800 border-gray-700 text-white font-mono"
                {...register("lowerPrice", { valueAsNumber: true })}
              />
              {errors.lowerPrice && (
                <p className="text-error text-xs mt-1">{errors.lowerPrice.message}</p>
              )}
            </div>
            <div>
              <Label htmlFor="upperPrice" className="text-sm font-medium text-gray-400 mb-2 block">
                Upper Price
              </Label>
              <Input
                id="upperPrice"
                type="number"
                step="0.01"
                placeholder="47,000"
                className="bg-gray-800 border-gray-700 text-white font-mono"
                {...register("upperPrice", { valueAsNumber: true })}
              />
              {errors.upperPrice && (
                <p className="text-error text-xs mt-1">{errors.upperPrice.message}</p>
              )}
            </div>
          </div>
          
          <div>
            <Label htmlFor="gridLevels" className="text-sm font-medium text-gray-400 mb-2 block">
              Grid Levels
            </Label>
            <Input
              id="gridLevels"
              type="number"
              placeholder="50"
              className="bg-gray-800 border-gray-700 text-white font-mono"
              {...register("gridLevels", { valueAsNumber: true })}
            />
            {errors.gridLevels && (
              <p className="text-error text-xs mt-1">{errors.gridLevels.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="investmentAmount" className="text-sm font-medium text-gray-400 mb-2 block">
              Investment Amount
            </Label>
            <Input
              id="investmentAmount"
              type="number"
              step="0.01"
              placeholder="1000"
              className="bg-gray-800 border-gray-700 text-white font-mono"
              {...register("investmentAmount", { valueAsNumber: true })}
            />
            {errors.investmentAmount && (
              <p className="text-error text-xs mt-1">{errors.investmentAmount.message}</p>
            )}
          </div>
          
          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90"
            disabled={createGridMutation.isPending}
          >
            {createGridMutation.isPending ? 'Creating...' : 'Create Grid Strategy'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}
