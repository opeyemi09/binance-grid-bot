import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Filter, RefreshCw, MoreVertical } from "lucide-react";
import type { GridStrategy } from "@shared/schema";

interface GridStrategiesProps {
  strategies: GridStrategy[];
}

export function GridStrategies({ strategies }: GridStrategiesProps) {
  const getSymbolIcon = (symbol: string) => {
    if (symbol.includes('BTC')) return '₿';
    if (symbol.includes('ETH')) return 'Ξ';
    if (symbol.includes('ADA')) return '₳';
    if (symbol.includes('SOL')) return '◎';
    return '◦';
  };

  const getSymbolColor = (symbol: string) => {
    if (symbol.includes('BTC')) return 'bg-yellow-500/20 text-yellow-400';
    if (symbol.includes('ETH')) return 'bg-blue-500/20 text-blue-400';
    if (symbol.includes('ADA')) return 'bg-green-500/20 text-green-400';
    if (symbol.includes('SOL')) return 'bg-purple-500/20 text-purple-400';
    return 'bg-gray-500/20 text-gray-400';
  };

  const getStatusVariant = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'paused': return 'secondary';
      case 'stopped': return 'destructive';
      default: return 'outline';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-success/20 text-success';
      case 'paused': return 'bg-warning/20 text-warning';
      case 'stopped': return 'bg-error/20 text-error';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <Card className="bg-surface border-gray-800">
      <CardHeader className="border-b border-gray-800">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Active Grid Strategies</CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <Filter className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="p-6">
        <div className="space-y-4">
          {strategies.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-400">No grid strategies found. Create your first grid to get started.</p>
            </div>
          ) : (
            strategies.map((strategy) => (
              <div 
                key={strategy.id} 
                className="border border-gray-700 rounded-lg p-4 hover:border-gray-600 transition-colors"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${getSymbolColor(strategy.symbol)}`}>
                      <span className="font-bold text-sm">{getSymbolIcon(strategy.symbol)}</span>
                    </div>
                    <div>
                      <h4 className="font-semibold">{strategy.symbol}</h4>
                      <p className="text-sm text-gray-400">Grid Trading</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge className={getStatusColor(strategy.status)}>
                      {strategy.status.charAt(0).toUpperCase() + strategy.status.slice(1)}
                    </Badge>
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                  <div>
                    <p className="text-xs text-gray-400">Current Price</p>
                    <p className="font-mono font-semibold">${strategy.currentPrice.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Grid Range</p>
                    <p className="font-mono text-sm">
                      ${strategy.lowerPrice.toLocaleString()} - ${strategy.upperPrice.toLocaleString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">P&L</p>
                    <p className={`font-mono font-semibold ${strategy.totalPnL >= 0 ? 'text-success' : 'text-error'}`}>
                      {strategy.totalPnL >= 0 ? '+' : ''}${strategy.totalPnL.toFixed(2)}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">Filled Orders</p>
                    <p className="font-mono text-sm">{strategy.filledOrders}/{strategy.totalOrders}</p>
                  </div>
                </div>
                
                {/* Grid Progress Bar */}
                <div className="space-y-2">
                  <Progress value={strategy.gridUtilization} className="h-2" />
                  <p className="text-xs text-gray-400">
                    Grid Utilization: {strategy.gridUtilization.toFixed(1)}%
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
