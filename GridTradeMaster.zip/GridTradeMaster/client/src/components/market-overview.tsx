import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import type { MarketData } from "@shared/schema";

export function MarketOverview() {
  const { data: marketData } = useQuery<MarketData[]>({
    queryKey: ['/api/market'],
    refetchInterval: 5000,
  });

  const getSymbolIcon = (symbol: string) => {
    if (symbol.includes('BTC')) return '₿';
    if (symbol.includes('ETH')) return 'Ξ';
    if (symbol.includes('SOL')) return '◎';
    if (symbol.includes('ADA')) return '₳';
    return '◦';
  };

  const getSymbolColor = (symbol: string) => {
    if (symbol.includes('BTC')) return 'bg-yellow-500/20 text-yellow-400';
    if (symbol.includes('ETH')) return 'bg-blue-500/20 text-blue-400';
    if (symbol.includes('SOL')) return 'bg-purple-500/20 text-purple-400';
    if (symbol.includes('ADA')) return 'bg-green-500/20 text-green-400';
    return 'bg-gray-500/20 text-gray-400';
  };

  const formatPrice = (price: number, symbol: string) => {
    if (symbol.includes('BTC') || symbol.includes('ETH')) {
      return `$${price.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
    }
    return `$${price.toFixed(2)}`;
  };

  return (
    <Card className="bg-surface border-gray-800">
      <CardHeader className="border-b border-gray-800">
        <CardTitle className="font-semibold">Market Overview</CardTitle>
      </CardHeader>
      <CardContent className="p-4 space-y-3">
        {marketData?.map((market) => (
          <div key={market.symbol} className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center ${getSymbolColor(market.symbol)}`}>
                <span className="text-xs">{getSymbolIcon(market.symbol)}</span>
              </div>
              <span className="font-medium text-sm">
                {market.symbol.split('/')[0]}
              </span>
            </div>
            <div className="text-right">
              <p className="font-mono text-sm">{formatPrice(market.price, market.symbol)}</p>
              <p className={`text-xs ${market.change24h >= 0 ? 'text-success' : 'text-error'}`}>
                {market.change24h >= 0 ? '+' : ''}{market.change24h.toFixed(2)}%
              </p>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
