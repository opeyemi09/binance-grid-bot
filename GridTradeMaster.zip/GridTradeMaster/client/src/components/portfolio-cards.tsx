import { Card, CardContent } from "@/components/ui/card";
import { Wallet, TrendingUp, Layers, Percent } from "lucide-react";
import type { PortfolioStats } from "@shared/schema";

interface PortfolioCardsProps {
  portfolioStats?: PortfolioStats;
}

export function PortfolioCards({ portfolioStats }: PortfolioCardsProps) {
  const cards = [
    {
      title: "Total Balance",
      value: `$${portfolioStats?.totalBalance?.toLocaleString('en-US', { minimumFractionDigits: 2 }) || '0.00'}`,
      change: "+5.23% (24h)",
      icon: Wallet,
      changeColor: "text-success"
    },
    {
      title: "Today's P&L",
      value: `+$${portfolioStats?.todayPnL?.toFixed(2) || '0.00'}`,
      change: "8 trades executed",
      icon: TrendingUp,
      changeColor: "text-success"
    },
    {
      title: "Active Positions",
      value: portfolioStats?.activePositions?.toString() || '0',
      change: "Across 7 pairs",
      icon: Layers,
      changeColor: "text-gray-400"
    },
    {
      title: "Grid Efficiency",
      value: `${portfolioStats?.gridEfficiency?.toFixed(1) || '0.0'}%`,
      change: "Avg fill rate",
      icon: Percent,
      changeColor: "text-success"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index} className="bg-surface border-gray-800">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-medium text-gray-400">{card.title}</h3>
                <Icon className="w-5 h-5 text-gray-500" />
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold font-mono">{card.value}</p>
                <p className={`text-sm ${card.changeColor}`}>{card.change}</p>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
