import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import type { GridStrategy, MarketData } from "@shared/schema";

interface PriceLadderProps {
  symbol: string;
  gridStrategy?: GridStrategy;
}

export function PriceLadder({ symbol, gridStrategy }: PriceLadderProps) {
  const { data: marketData } = useQuery<MarketData[]>({
    queryKey: ['/api/market'],
    refetchInterval: 2000,
  });

  const currentMarket = marketData?.find(m => m.symbol === symbol);
  const currentPrice = currentMarket?.price || gridStrategy?.currentPrice || 0;

  if (!gridStrategy) {
    return (
      <Card className="bg-surface border-gray-800">
        <CardHeader>
          <CardTitle className="text-sm font-semibold">Price Ladder</CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="text-center text-gray-400">
            <p>Select a grid strategy to view price ladder</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate grid levels
  const priceRange = gridStrategy.upperPrice - gridStrategy.lowerPrice;
  const gridStep = priceRange / gridStrategy.gridLevels;
  const levels = [];

  for (let i = 0; i <= gridStrategy.gridLevels; i++) {
    const price = gridStrategy.lowerPrice + (i * gridStep);
    const isCurrentLevel = Math.abs(price - currentPrice) < gridStep / 2;
    const isBuyLevel = price < currentPrice;
    const isSellLevel = price > currentPrice;
    
    levels.push({
      price,
      level: i,
      isCurrentLevel,
      isBuyLevel,
      isSellLevel,
      distance: Math.abs(price - currentPrice),
    });
  }

  // Sort by price descending (highest first)
  levels.sort((a, b) => b.price - a.price);

  // Show only levels around current price (±10 levels)
  const currentIndex = levels.findIndex(l => l.isCurrentLevel);
  const startIndex = Math.max(0, currentIndex - 10);
  const endIndex = Math.min(levels.length, currentIndex + 11);
  const visibleLevels = levels.slice(startIndex, endIndex);

  const formatPrice = (price: number) => {
    if (symbol.includes('BTC') || symbol.includes('ETH')) {
      return `$${price.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
    }
    return `$${price.toFixed(2)}`;
  };

  return (
    <Card className="bg-surface border-gray-800">
      <CardHeader className="border-b border-gray-800">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-semibold">Price Ladder</CardTitle>
          <Badge variant="outline" className="text-xs">
            {symbol}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="p-2">
        <div className="space-y-0.5 max-h-96 overflow-y-auto">
          {visibleLevels.map((level, index) => (
            <div
              key={level.level}
              className={`
                flex items-center justify-between px-2 py-1 text-xs rounded
                ${level.isCurrentLevel 
                  ? 'bg-blue-500/20 border border-blue-500/50 text-blue-300' 
                  : level.isSellLevel 
                    ? 'bg-red-500/10 text-red-300 hover:bg-red-500/20' 
                    : 'bg-green-500/10 text-green-300 hover:bg-green-500/20'
                }
                cursor-pointer transition-colors
              `}
            >
              <div className="flex items-center space-x-2">
                <span className="font-mono text-xs">
                  {formatPrice(level.price)}
                </span>
                {level.isCurrentLevel && (
                  <span className="text-xs bg-blue-500 px-1 rounded">CURRENT</span>
                )}
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-xs text-gray-400">
                  L{level.level}
                </span>
                {level.isBuyLevel && (
                  <span className="text-xs text-green-400">BUY</span>
                )}
                {level.isSellLevel && (
                  <span className="text-xs text-red-400">SELL</span>
                )}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-3 border-t border-gray-700 space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">Grid Range:</span>
            <span className="font-mono">
              {formatPrice(gridStrategy.lowerPrice)} - {formatPrice(gridStrategy.upperPrice)}
            </span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">Grid Levels:</span>
            <span className="font-mono">{gridStrategy.gridLevels}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">Step Size:</span>
            <span className="font-mono">${gridStep.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">Current Price:</span>
            <span className="font-mono text-blue-300">
              {formatPrice(currentPrice)}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}