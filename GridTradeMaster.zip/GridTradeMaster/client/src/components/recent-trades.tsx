import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import type { Trade } from "@shared/schema";

export function RecentTrades() {
  const { data: trades } = useQuery<Trade[]>({
    queryKey: ['/api/trades/recent'],
    refetchInterval: 5000,
  });

  const formatTime = (timestamp: string | Date) => {
    const date = typeof timestamp === 'string' ? new Date(timestamp) : timestamp;
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false,
    });
  };

  return (
    <Card className="bg-surface border-gray-800">
      <CardHeader className="border-b border-gray-800">
        <CardTitle className="font-semibold">Recent Trades</CardTitle>
      </CardHeader>
      <CardContent className="p-4 space-y-3">
        {trades?.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-gray-400 text-sm">No recent trades</p>
          </div>
        ) : (
          trades?.map((trade) => (
            <div key={trade.id} className="flex items-center justify-between">
              <div>
                <p className="font-medium text-sm">{trade.symbol}</p>
                <p className="text-xs text-gray-400">{formatTime(trade.timestamp)}</p>
              </div>
              <div className="text-right">
                <p className={`font-mono text-sm ${trade.side === 'buy' ? 'text-success' : 'text-error'}`}>
                  {trade.side.toUpperCase()}
                </p>
                <p className="text-xs text-gray-400">{trade.quantity.toFixed(4)}</p>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
