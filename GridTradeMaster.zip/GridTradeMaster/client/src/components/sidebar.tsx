import { 
  BarChart3, 
  Grid3X3, 
  Wallet, 
  History, 
  Settings,
  Bot,
  Circle
} from "lucide-react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const navigation = [
  { name: 'Dashboard', href: '/', icon: BarChart3, current: true },
  { name: 'Grid Strategies', href: '/strategies', icon: Grid3X3, current: false },
  { name: 'Portfolio', href: '/portfolio', icon: Wallet, current: false },
  { name: 'Trade History', href: '/history', icon: History, current: false },
  { name: 'Settings', href: '/settings', icon: Settings, current: false },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-surface border-r border-gray-800 flex flex-col">
      {/* Logo Header */}
      <div className="p-6 border-b border-gray-800">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Bot className="w-4 h-4 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-white">GridBot Pro</h1>
            <p className="text-xs text-gray-400">Trading Dashboard</p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.href;
          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                isActive
                  ? 'bg-primary/20 text-primary'
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white',
                'flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors'
              )}
            >
              <Icon className="w-5 h-5" />
              <span>{item.name}</span>
            </Link>
          );
        })}
      </nav>

      {/* Connection Status */}
      <div className="p-4 border-t border-gray-800">
        <div className="flex items-center space-x-2 text-sm">
          <Circle className="w-2 h-2 bg-success rounded-full animate-pulse fill-current" />
          <span className="text-gray-300">Binance Connected</span>
        </div>
        <div className="flex items-center space-x-2 text-sm mt-1">
          <Circle className="w-2 h-2 bg-success rounded-full animate-pulse fill-current" />
          <span className="text-gray-300">Telegram Active</span>
        </div>
      </div>
    </aside>
  );
}
