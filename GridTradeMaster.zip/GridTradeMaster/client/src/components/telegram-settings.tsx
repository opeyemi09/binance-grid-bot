import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { MessageCircle, TestTube, CheckCircle, XCircle } from "lucide-react";
import { useState } from "react";

interface TelegramSettingsData {
  userId: number;
  botToken: string;
  chatId: string;
  alertsEnabled: boolean;
  tradeAlerts: boolean;
  profitAlerts: boolean;
}

export function TelegramSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'error'>('idle');

  const { data: settings } = useQuery<TelegramSettingsData>({
    queryKey: ['/api/telegram/settings/1'],
  });

  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<TelegramSettingsData>({
    defaultValues: settings || {
      userId: 1,
      botToken: '',
      chatId: '',
      alertsEnabled: true,
      tradeAlerts: true,
      profitAlerts: true,
    }
  });

  const saveMutation = useMutation({
    mutationFn: async (data: TelegramSettingsData) => {
      const response = await apiRequest('POST', '/api/telegram/settings', data);
      return response.json();
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['/api/telegram/settings/1'] });
      setTestStatus(result.connected ? 'success' : 'error');
      toast({
        title: "Settings Saved",
        description: result.connected 
          ? "Telegram bot connected successfully!" 
          : "Settings saved but connection test failed",
        variant: result.connected ? "default" : "destructive",
      });
    },
    onError: () => {
      setTestStatus('error');
      toast({
        title: "Error",
        description: "Failed to save Telegram settings",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TelegramSettingsData) => {
    setTestStatus('testing');
    saveMutation.mutate(data);
  };

  const watchedValues = watch();

  return (
    <Card className="bg-surface border-gray-800">
      <CardHeader className="border-b border-gray-800">
        <div className="flex items-center space-x-2">
          <MessageCircle className="w-5 h-5 text-blue-400" />
          <CardTitle className="font-semibold">Telegram Alerts</CardTitle>
          {testStatus === 'success' && <CheckCircle className="w-4 h-4 text-green-400" />}
          {testStatus === 'error' && <XCircle className="w-4 h-4 text-red-400" />}
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div>
            <Label htmlFor="botToken" className="text-sm font-medium text-gray-400 mb-2 block">
              Bot Token
            </Label>
            <Input
              id="botToken"
              type="password"
              placeholder="1234567890:ABCdefGHIjklMNOpqrsTUVwxyz"
              className="bg-gray-800 border-gray-700 text-white font-mono text-xs"
              {...register("botToken", { required: "Bot token is required" })}
            />
            {errors.botToken && (
              <p className="text-red-400 text-xs mt-1">{errors.botToken.message}</p>
            )}
            <p className="text-xs text-gray-500 mt-1">
              Get your bot token from @BotFather on Telegram
            </p>
          </div>

          <div>
            <Label htmlFor="chatId" className="text-sm font-medium text-gray-400 mb-2 block">
              Chat ID
            </Label>
            <Input
              id="chatId"
              placeholder="-1001234567890 or 123456789"
              className="bg-gray-800 border-gray-700 text-white font-mono"
              {...register("chatId", { required: "Chat ID is required" })}
            />
            {errors.chatId && (
              <p className="text-red-400 text-xs mt-1">{errors.chatId.message}</p>
            )}
            <p className="text-xs text-gray-500 mt-1">
              Your personal chat ID or group chat ID
            </p>
          </div>

          <div className="space-y-3 pt-2 border-t border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium text-gray-300">Enable Alerts</Label>
                <p className="text-xs text-gray-500">Master switch for all notifications</p>
              </div>
              <Switch
                checked={watchedValues.alertsEnabled}
                onCheckedChange={(checked) => setValue('alertsEnabled', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium text-gray-300">Trade Alerts</Label>
                <p className="text-xs text-gray-500">Get notified on buy/sell orders</p>
              </div>
              <Switch
                checked={watchedValues.tradeAlerts}
                onCheckedChange={(checked) => setValue('tradeAlerts', checked)}
                disabled={!watchedValues.alertsEnabled}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium text-gray-300">Profit Alerts</Label>
                <p className="text-xs text-gray-500">Get notified on profit milestones</p>
              </div>
              <Switch
                checked={watchedValues.profitAlerts}
                onCheckedChange={(checked) => setValue('profitAlerts', checked)}
                disabled={!watchedValues.alertsEnabled}
              />
            </div>
          </div>

          <div className="flex space-x-2 pt-2">
            <Button
              type="submit"
              className="flex-1 bg-blue-600 hover:bg-blue-700"
              disabled={saveMutation.isPending}
            >
              {testStatus === 'testing' ? (
                <>
                  <TestTube className="w-4 h-4 mr-2 animate-spin" />
                  Testing...
                </>
              ) : (
                'Save & Test'
              )}
            </Button>
          </div>

          {testStatus === 'success' && (
            <div className="bg-green-500/20 border border-green-500/50 rounded p-3">
              <p className="text-green-300 text-sm">
                ✅ Connection successful! You'll receive alerts on trades and profits.
              </p>
            </div>
          )}

          {testStatus === 'error' && (
            <div className="bg-red-500/20 border border-red-500/50 rounded p-3">
              <p className="text-red-300 text-sm">
                ❌ Connection failed. Please check your bot token and chat ID.
              </p>
            </div>
          )}
        </form>
      </CardContent>
    </Card>
  );
}