export interface GridLevel {
  price: number;
  quantity: number;
  side: 'buy' | 'sell';
  filled: boolean;
}

export function calculateGridLevels(
  lowerPrice: number,
  upperPrice: number,
  gridLevels: number,
  investmentAmount: number
): GridLevel[] {
  const priceRange = upperPrice - lowerPrice;
  const priceStep = priceRange / (gridLevels - 1);
  const levels: GridLevel[] = [];
  
  for (let i = 0; i < gridLevels; i++) {
    const price = lowerPrice + (i * priceStep);
    const quantity = investmentAmount / gridLevels / price;
    const side = i < gridLevels / 2 ? 'buy' : 'sell';
    
    levels.push({
      price,
      quantity,
      side,
      filled: false
    });
  }
  
  return levels;
}

export function calculateProfitTarget(buyPrice: number, profitPercentage: number): number {
  return buyPrice * (1 + profitPercentage / 100);
}

export function calculateStopLoss(buyPrice: number, stopLossPercentage: number): number {
  return buyPrice * (1 - stopLossPercentage / 100);
}

export function formatCurrency(
  amount: number,
  currency: string = 'USD',
  minimumFractionDigits: number = 2
): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits,
    maximumFractionDigits: minimumFractionDigits,
  }).format(amount);
}

export function formatPercentage(value: number, decimals: number = 2): string {
  return `${value >= 0 ? '+' : ''}${value.toFixed(decimals)}%`;
}

export function calculateGridProfit(
  trades: Array<{ side: string; price: number; quantity: number; pnl: number }>
): { totalProfit: number; totalTrades: number; profitableTrades: number } {
  const totalProfit = trades.reduce((sum, trade) => sum + trade.pnl, 0);
  const totalTrades = trades.length;
  const profitableTrades = trades.filter(trade => trade.pnl > 0).length;
  
  return {
    totalProfit,
    totalTrades,
    profitableTrades,
  };
}

export function calculateOptimalGridSpacing(
  volatility: number,
  minSpacing: number = 0.5,
  maxSpacing: number = 5.0
): number {
  // Higher volatility = wider spacing
  const spacing = volatility * 2;
  return Math.max(minSpacing, Math.min(maxSpacing, spacing));
}

export function validateGridParameters(
  lowerPrice: number,
  upperPrice: number,
  gridLevels: number,
  investmentAmount: number
): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  if (lowerPrice <= 0) {
    errors.push('Lower price must be greater than 0');
  }
  
  if (upperPrice <= lowerPrice) {
    errors.push('Upper price must be greater than lower price');
  }
  
  if (gridLevels < 2) {
    errors.push('Grid levels must be at least 2');
  }
  
  if (gridLevels > 200) {
    errors.push('Grid levels cannot exceed 200');
  }
  
  if (investmentAmount <= 0) {
    errors.push('Investment amount must be greater than 0');
  }
  
  const minInvestmentPerLevel = 10; // Minimum $10 per level
  if (investmentAmount / gridLevels < minInvestmentPerLevel) {
    errors.push(`Investment amount too small for ${gridLevels} levels. Minimum $${minInvestmentPerLevel * gridLevels} required.`);
  }
  
  return {
    isValid: errors.length === 0,
    errors,
  };
}
