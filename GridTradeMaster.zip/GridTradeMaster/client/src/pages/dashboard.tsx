import { Sidebar } from "@/components/sidebar";
import { PortfolioCards } from "@/components/portfolio-cards";
import { GridStrategies } from "@/components/grid-strategies";
import { MarketOverview } from "@/components/market-overview";
import { RecentTrades } from "@/components/recent-trades";
import { GridConfig } from "@/components/grid-config";
import { PriceLadder } from "@/components/price-ladder";
import { TelegramSettings } from "@/components/telegram-settings";
import { useWebSocket } from "@/hooks/use-websocket";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Plus, Pause, Play, Square } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import type { GridStrategy, PortfolioStats } from "@shared/schema";

export default function Dashboard() {
  const { toast } = useToast();
  const { isConnected, lastUpdate } = useWebSocket();
  const queryClient = useQueryClient();
  const [isTradingActive, setIsTradingActive] = useState(true);

  // Fetch portfolio stats
  const { data: portfolioStats } = useQuery<PortfolioStats>({
    queryKey: ['/api/portfolio/1'],
    refetchInterval: 5000,
  });

  // Fetch grid strategies
  const { data: strategies } = useQuery<GridStrategy[]>({
    queryKey: ['/api/strategies/1'],
    refetchInterval: 5000,
  });

  // Start/Stop trading mutation
  const toggleTradingMutation = useMutation({
    mutationFn: async (action: 'start' | 'stop') => {
      const response = await apiRequest('POST', `/api/trading/${action}`, {});
      return response.json();
    },
    onSuccess: (_, action) => {
      setIsTradingActive(action === 'start');
      toast({
        title: action === 'start' ? "Trading Started" : "Trading Stopped",
        description: action === 'start' 
          ? "All grid strategies are now active" 
          : "All trading activities have been paused",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to toggle trading status",
        variant: "destructive",
      });
    },
  });

  const handleToggleTrading = () => {
    const action = isTradingActive ? 'stop' : 'start';
    toggleTradingMutation.mutate(action);
  };

  const handlePauseAll = () => {
    toggleTradingMutation.mutate('stop');
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    });
  };

  return (
    <div className="flex h-screen bg-background text-foreground">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="bg-surface border-b border-gray-800 px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <h2 className="text-xl font-semibold">Trading Dashboard</h2>
              <div className="flex items-center space-x-4 text-sm">
                <span className="text-gray-400">Total P&L:</span>
                <span className="text-success font-mono font-bold">
                  +${portfolioStats?.totalPnL?.toFixed(2) || "0.00"}
                </span>
                <span className="text-gray-400">|</span>
                <span className="text-gray-400">Active Grids:</span>
                <span className="text-white font-mono">
                  {strategies?.filter(s => s.status === 'active').length || 0}
                </span>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Button
                onClick={handleToggleTrading}
                className={isTradingActive 
                  ? "bg-red-600 hover:bg-red-700" 
                  : "bg-green-600 hover:bg-green-700"
                }
                disabled={toggleTradingMutation.isPending}
              >
                {isTradingActive ? (
                  <>
                    <Square className="w-4 h-4 mr-2" />
                    Stop Trading
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 mr-2" />
                    Start Trading
                  </>
                )}
              </Button>
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="w-4 h-4 mr-2" />
                New Grid
              </Button>
              <div className="flex items-center space-x-2 text-sm">
                <span className="text-gray-400">Last Update:</span>
                <span className="text-gray-300 font-mono">
                  {lastUpdate ? formatTime(lastUpdate) : '--:--:--'}
                </span>
                <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-success animate-pulse' : 'bg-error'}`} />
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <div className="flex-1 p-6 overflow-y-auto">
          {/* Portfolio Overview Cards */}
          <PortfolioCards portfolioStats={portfolioStats} />

          {/* Main Trading Grid Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Active Grid Strategies */}
            <div className="lg:col-span-2">
              <GridStrategies strategies={strategies || []} />
            </div>

            {/* Price Ladder */}
            <div>
              <PriceLadder 
                symbol="BTC/USDT" 
                gridStrategy={strategies?.find(s => s.symbol === 'BTC/USDT')} 
              />
            </div>

            {/* Right Sidebar Panels */}
            <div className="space-y-6">
              <MarketOverview />
              <RecentTrades />
              <GridConfig />
              <TelegramSettings />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
