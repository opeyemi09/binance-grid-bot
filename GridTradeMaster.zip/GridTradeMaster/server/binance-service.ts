import Binance from 'binance-api-node';
import type { CandlestickData, InsertCandlestickData } from '@shared/schema';

export class BinanceService {
  private client: any;
  private isConnected = false;

  constructor() {
    this.initializeClient();
  }

  private initializeClient() {
    try {
      // Initialize with API credentials if available
      const apiKey = process.env.BINANCE_API_KEY;
      const apiSecret = process.env.BINANCE_API_SECRET;

      if (apiKey && apiSecret) {
        this.client = Binance({
          apiKey,
          apiSecret,
        });
        this.isConnected = true;
        console.log('Binance API client initialized with credentials');
      } else {
        // Initialize without credentials for public data only
        this.client = Binance();
        console.log('Binance API client initialized without credentials (public data only)');
      }
    } catch (error) {
      console.error('Failed to initialize Binance client:', error);
      this.isConnected = false;
    }
  }

  async getMarketPrice(symbol: string): Promise<number | null> {
    try {
      const ticker = await this.client.prices({ symbol: symbol.replace('/', '') });
      return parseFloat(ticker[symbol.replace('/', '')]);
    } catch (error) {
      console.error(`Failed to get price for ${symbol}:`, error);
      return null;
    }
  }

  async get24hrStats(symbol: string): Promise<{ price: number; change: number; volume: number } | null> {
    try {
      const stats = await this.client.dailyStats({ symbol: symbol.replace('/', '') });
      return {
        price: parseFloat(stats.lastPrice),
        change: parseFloat(stats.priceChangePercent),
        volume: parseFloat(stats.volume),
      };
    } catch (error) {
      console.error(`Failed to get 24hr stats for ${symbol}:`, error);
      return null;
    }
  }

  async getCandlestickData(
    symbol: string, 
    interval: string = '1m', 
    limit: number = 100
  ): Promise<InsertCandlestickData[]> {
    try {
      const candles = await this.client.candles({
        symbol: symbol.replace('/', ''),
        interval,
        limit,
      });

      return candles.map((candle: any) => ({
        symbol,
        open: parseFloat(candle.open),
        high: parseFloat(candle.high),
        low: parseFloat(candle.low),
        close: parseFloat(candle.close),
        volume: parseFloat(candle.volume),
        timestamp: new Date(candle.openTime),
      }));
    } catch (error) {
      console.error(`Failed to get candlestick data for ${symbol}:`, error);
      return [];
    }
  }

  async placeOrder(orderData: {
    symbol: string;
    side: 'BUY' | 'SELL';
    type: 'LIMIT' | 'MARKET';
    quantity: number;
    price?: number;
    timeInForce?: 'GTC' | 'IOC' | 'FOK';
  }): Promise<any> {
    if (!this.isConnected) {
      throw new Error('Binance API not connected with trading credentials');
    }

    try {
      const order = await this.client.order({
        symbol: orderData.symbol.replace('/', ''),
        side: orderData.side,
        type: orderData.type,
        quantity: orderData.quantity.toString(),
        price: orderData.price?.toString(),
        timeInForce: orderData.timeInForce || 'GTC',
      });

      return order;
    } catch (error) {
      console.error('Failed to place order:', error);
      throw error;
    }
  }

  async getAccountInfo(): Promise<any> {
    if (!this.isConnected) {
      throw new Error('Binance API not connected with trading credentials');
    }

    try {
      return await this.client.accountInfo();
    } catch (error) {
      console.error('Failed to get account info:', error);
      throw error;
    }
  }

  // WebSocket stream for real-time data
  startPriceStream(symbols: string[], callback: (data: any) => void) {
    try {
      const streams = symbols.map(symbol => `${symbol.toLowerCase().replace('/', '')}@ticker`);
      
      this.client.ws.ticker(streams, (ticker: any) => {
        callback({
          symbol: ticker.symbol,
          price: parseFloat(ticker.curDayClose),
          change: parseFloat(ticker.priceChangePercent),
          volume: parseFloat(ticker.volume),
        });
      });

      console.log('Started Binance price streams for:', symbols);
    } catch (error) {
      console.error('Failed to start price stream:', error);
    }
  }

  startCandlestickStream(symbol: string, interval: string, callback: (data: any) => void) {
    try {
      this.client.ws.candles(symbol.replace('/', ''), interval, (candle: any) => {
        callback({
          symbol,
          open: parseFloat(candle.open),
          high: parseFloat(candle.high),
          low: parseFloat(candle.low),
          close: parseFloat(candle.close),
          volume: parseFloat(candle.volume),
          timestamp: new Date(candle.eventTime),
        });
      });

      console.log(`Started candlestick stream for ${symbol} (${interval})`);
    } catch (error) {
      console.error('Failed to start candlestick stream:', error);
    }
  }

  isApiConnected(): boolean {
    return this.isConnected;
  }
}

export const binanceService = new BinanceService();