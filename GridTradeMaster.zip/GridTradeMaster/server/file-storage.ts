import fs from 'fs/promises';
import path from 'path';
import type { GridStrategy, Trade, InsertTrade } from "@shared/schema";

export class FileStorage {
  private dataDir: string;

  constructor() {
    this.dataDir = path.join(process.cwd(), 'data');
    this.ensureDataDirectory();
  }

  private async ensureDataDirectory() {
    try {
      await fs.access(this.dataDir);
    } catch {
      await fs.mkdir(this.dataDir, { recursive: true });
    }
  }

  async saveGridStrategy(strategy: GridStrategy): Promise<void> {
    try {
      const filename = path.join(this.dataDir, `strategy_${strategy.id}.json`);
      await fs.writeFile(filename, JSON.stringify(strategy, null, 2));
    } catch (error) {
      console.error('Error saving grid strategy:', error);
    }
  }

  async loadGridStrategy(id: number): Promise<GridStrategy | null> {
    try {
      const filename = path.join(this.dataDir, `strategy_${id}.json`);
      const data = await fs.readFile(filename, 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      console.error(`Error loading grid strategy ${id}:`, error);
      return null;
    }
  }

  async saveTrade(trade: InsertTrade): Promise<void> {
    try {
      const filename = path.join(this.dataDir, 'trades.jsonl');
      const tradeWithTimestamp = {
        ...trade,
        timestamp: new Date().toISOString()
      };
      const line = JSON.stringify(tradeWithTimestamp) + '\n';
      await fs.appendFile(filename, line);
    } catch (error) {
      console.error('Error saving trade:', error);
    }
  }

  async loadTrades(): Promise<Trade[]> {
    try {
      const filename = path.join(this.dataDir, 'trades.jsonl');
      const data = await fs.readFile(filename, 'utf-8');
      return data.trim().split('\n')
        .filter(line => line.trim())
        .map(line => JSON.parse(line));
    } catch (error) {
      console.error('Error loading trades:', error);
      return [];
    }
  }

  async saveSettings(settings: any): Promise<void> {
    try {
      const filename = path.join(this.dataDir, 'settings.json');
      await fs.writeFile(filename, JSON.stringify(settings, null, 2));
    } catch (error) {
      console.error('Error saving settings:', error);
    }
  }

  async loadSettings(): Promise<any> {
    try {
      const filename = path.join(this.dataDir, 'settings.json');
      const data = await fs.readFile(filename, 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      console.error('Error loading settings:', error);
      return {};
    }
  }

  async saveOrdersAndProfits(data: {
    orders: any[];
    profits: { [symbol: string]: number };
    totalProfit: number;
    timestamp: string;
  }): Promise<void> {
    try {
      const filename = path.join(this.dataDir, 'orders_and_profits.json');
      await fs.writeFile(filename, JSON.stringify(data, null, 2));
    } catch (error) {
      console.error('Error saving orders and profits:', error);
    }
  }

  async loadOrdersAndProfits(): Promise<any> {
    try {
      const filename = path.join(this.dataDir, 'orders_and_profits.json');
      const data = await fs.readFile(filename, 'utf-8');
      return JSON.parse(data);
    } catch (error) {
      console.error('Error loading orders and profits:', error);
      return { orders: [], profits: {}, totalProfit: 0 };
    }
  }

  async saveDailyReport(report: any): Promise<void> {
    try {
      const date = new Date().toISOString().split('T')[0];
      const filename = path.join(this.dataDir, `daily_report_${date}.json`);
      await fs.writeFile(filename, JSON.stringify(report, null, 2));
    } catch (error) {
      console.error('Error saving daily report:', error);
    }
  }
}
