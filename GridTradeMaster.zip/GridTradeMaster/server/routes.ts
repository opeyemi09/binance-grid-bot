import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { TradingEngine } from "./trading-engine";
import { FileStorage } from "./file-storage";
import { binanceService } from "./binance-service";
import { telegramService } from "./telegram-service";
import { insertGridStrategySchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const fileStorage = new FileStorage();
  const tradingEngine = new TradingEngine(storage, fileStorage);
  
  // Initialize WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('Client connected');
    
    // Send initial data
    ws.send(JSON.stringify({
      type: 'connected',
      message: 'WebSocket connection established'
    }));
    
    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected');
    });
    
    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });
  
  // Broadcast function
  function broadcast(data: any) {
    const message = JSON.stringify(data);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }
  
  // Start trading engine
  tradingEngine.start(broadcast);
  
  // API Routes
  
  // Get portfolio stats
  app.get('/api/portfolio/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const stats = await storage.getPortfolioStats(userId);
      if (!stats) {
        return res.status(404).json({ message: 'Portfolio not found' });
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get portfolio stats' });
    }
  });
  
  // Get grid strategies
  app.get('/api/strategies/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      const strategies = await storage.getGridStrategies(userId);
      res.json(strategies);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get grid strategies' });
    }
  });
  
  // Create grid strategy
  app.post('/api/strategies', async (req, res) => {
    try {
      const validatedData = insertGridStrategySchema.parse(req.body);
      const userId = 1; // Default user for demo
      
      const strategy = await storage.createGridStrategy({
        ...validatedData,
        userId
      });
      
      // Save to file
      await fileStorage.saveGridStrategy(strategy);
      
      // Notify trading engine
      tradingEngine.addStrategy(strategy);
      
      res.status(201).json(strategy);
    } catch (error) {
      console.error('Failed to create grid strategy:', error);
      res.status(400).json({ message: 'Failed to create grid strategy' });
    }
  });
  
  // Update grid strategy
  app.patch('/api/strategies/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      
      const strategy = await storage.updateGridStrategy(id, updates);
      if (!strategy) {
        return res.status(404).json({ message: 'Strategy not found' });
      }
      
      // Save to file
      await fileStorage.saveGridStrategy(strategy);
      
      res.json(strategy);
    } catch (error) {
      res.status(500).json({ message: 'Failed to update grid strategy' });
    }
  });
  
  // Delete grid strategy
  app.delete('/api/strategies/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const success = await storage.deleteGridStrategy(id);
      
      if (!success) {
        return res.status(404).json({ message: 'Strategy not found' });
      }
      
      // Remove from trading engine
      tradingEngine.removeStrategy(id);
      
      res.json({ message: 'Strategy deleted successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to delete grid strategy' });
    }
  });
  
  // Get market data
  app.get('/api/market', async (req, res) => {
    try {
      const marketData = await storage.getMarketData();
      res.json(marketData);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get market data' });
    }
  });
  
  // Get recent trades
  app.get('/api/trades/recent', async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const trades = await storage.getRecentTrades(limit);
      res.json(trades);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get recent trades' });
    }
  });
  
  // Get trades for specific strategy
  app.get('/api/trades/:strategyId', async (req, res) => {
    try {
      const strategyId = parseInt(req.params.strategyId);
      const trades = await storage.getTrades(strategyId);
      res.json(trades);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get trades' });
    }
  });

  // Get candlestick data
  app.get('/api/candlestick/:symbol/:interval', async (req, res) => {
    try {
      const { symbol, interval } = req.params;
      const data = await binanceService.getCandlestickData(symbol, interval);
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get candlestick data' });
    }
  });

  // Telegram settings endpoints
  app.get('/api/telegram/settings/:userId', async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      // For demo, return default settings
      const settings = {
        id: 1,
        userId,
        botToken: '',
        chatId: '',
        alertsEnabled: true,
        tradeAlerts: true,
        profitAlerts: true,
      };
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: 'Failed to get Telegram settings' });
    }
  });

  app.post('/api/telegram/settings', async (req, res) => {
    try {
      const settings = req.body;
      telegramService.updateSettings(settings);
      
      // Test connection
      const connected = await telegramService.testConnection();
      res.json({ ...settings, connected });
    } catch (error) {
      res.status(500).json({ message: 'Failed to update Telegram settings' });
    }
  });

  // Trading control endpoints
  app.post('/api/trading/start', async (req, res) => {
    try {
      // Resume all active strategies
      const strategies = await storage.getGridStrategies(1);
      for (const strategy of strategies) {
        if (strategy.status === 'paused') {
          await storage.updateGridStrategy(strategy.id, { status: 'active' });
          tradingEngine.addStrategy({ ...strategy, status: 'active' });
        }
      }

      // Send Telegram notification
      await telegramService.sendGridStatusAlert(strategies[0], 'started');

      res.json({ message: 'Trading started', status: 'active' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to start trading' });
    }
  });

  app.post('/api/trading/stop', async (req, res) => {
    try {
      // Pause all active strategies
      const strategies = await storage.getGridStrategies(1);
      for (const strategy of strategies) {
        if (strategy.status === 'active') {
          await storage.updateGridStrategy(strategy.id, { status: 'paused' });
          tradingEngine.removeStrategy(strategy.id);
        }
      }

      // Send Telegram notification
      await telegramService.sendGridStatusAlert(strategies[0], 'paused');

      res.json({ message: 'Trading stopped', status: 'paused' });
    } catch (error) {
      res.status(500).json({ message: 'Failed to stop trading' });
    }
  });

  return httpServer;
}
