import { 
  users, 
  gridStrategies, 
  trades, 
  portfolioStats, 
  marketData,
  type User, 
  type InsertUser,
  type GridStrategy,
  type InsertGridStrategy,
  type Trade,
  type InsertTrade,
  type PortfolioStats,
  type MarketData,
  type InsertMarketData
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Grid strategy methods
  getGridStrategies(userId: number): Promise<GridStrategy[]>;
  getGridStrategy(id: number): Promise<GridStrategy | undefined>;
  createGridStrategy(strategy: InsertGridStrategy & { userId: number }): Promise<GridStrategy>;
  updateGridStrategy(id: number, updates: Partial<GridStrategy>): Promise<GridStrategy | undefined>;
  deleteGridStrategy(id: number): Promise<boolean>;
  
  // Trade methods
  getTrades(gridStrategyId: number): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  getRecentTrades(limit?: number): Promise<Trade[]>;
  
  // Portfolio methods
  getPortfolioStats(userId: number): Promise<PortfolioStats | undefined>;
  updatePortfolioStats(userId: number, stats: Partial<PortfolioStats>): Promise<PortfolioStats>;
  
  // Market data methods
  getMarketData(): Promise<MarketData[]>;
  updateMarketData(symbol: string, data: InsertMarketData): Promise<MarketData>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private gridStrategies: Map<number, GridStrategy> = new Map();
  private trades: Map<number, Trade> = new Map();
  private portfolioStats: Map<number, PortfolioStats> = new Map();
  private marketData: Map<string, MarketData> = new Map();
  private currentUserId = 1;
  private currentGridId = 1;
  private currentTradeId = 1;
  private currentPortfolioId = 1;
  private currentMarketId = 1;

  constructor() {
    // Initialize with some default data
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default user
    const defaultUser: User = {
      id: 1,
      username: "trader",
      password: "password123"
    };
    this.users.set(1, defaultUser);

    // Initialize portfolio stats
    const defaultPortfolio: PortfolioStats = {
      id: 1,
      userId: 1,
      totalBalance: 45823.67,
      totalPnL: 2847.23,
      todayPnL: 342.18,
      activePositions: 12,
      gridEfficiency: 87.3,
      lastUpdated: new Date()
    };
    this.portfolioStats.set(1, defaultPortfolio);

    // Initialize market data
    const markets = [
      { symbol: "BTC/USDT", price: 43567.23, change24h: 2.34, volume: 125000000 },
      { symbol: "ETH/USDT", price: 2687.91, change24h: 1.89, volume: 85000000 },
      { symbol: "SOL/USDT", price: 98.45, change24h: -0.67, volume: 45000000 },
      { symbol: "ADA/USDT", price: 0.4823, change24h: 0.12, volume: 15000000 }
    ];

    markets.forEach((market, index) => {
      const marketData: MarketData = {
        id: index + 1,
        symbol: market.symbol,
        price: market.price,
        change24h: market.change24h,
        volume: market.volume,
        lastUpdated: new Date()
      };
      this.marketData.set(market.symbol, marketData);
    });

    // Initialize some grid strategies
    const defaultStrategies = [
      {
        id: 1,
        userId: 1,
        symbol: "BTC/USDT",
        status: "active" as const,
        lowerPrice: 40000,
        upperPrice: 47000,
        gridLevels: 50,
        investmentAmount: 10000,
        currentPrice: 43567.23,
        totalPnL: 1234.56,
        filledOrders: 23,
        totalOrders: 50,
        gridUtilization: 46,
        createdAt: new Date()
      },
      {
        id: 2,
        userId: 1,
        symbol: "ETH/USDT",
        status: "active" as const,
        lowerPrice: 2500,
        upperPrice: 3000,
        gridLevels: 40,
        investmentAmount: 8000,
        currentPrice: 2687.91,
        totalPnL: 856.34,
        filledOrders: 18,
        totalOrders: 40,
        gridUtilization: 45,
        createdAt: new Date()
      }
    ];

    defaultStrategies.forEach(strategy => {
      this.gridStrategies.set(strategy.id, strategy);
    });

    this.currentUserId = 2;
    this.currentGridId = 3;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getGridStrategies(userId: number): Promise<GridStrategy[]> {
    return Array.from(this.gridStrategies.values()).filter(
      strategy => strategy.userId === userId
    );
  }

  async getGridStrategy(id: number): Promise<GridStrategy | undefined> {
    return this.gridStrategies.get(id);
  }

  async createGridStrategy(strategy: InsertGridStrategy & { userId: number }): Promise<GridStrategy> {
    const id = this.currentGridId++;
    const currentPrice = this.marketData.get(strategy.symbol)?.price || strategy.lowerPrice;
    
    const newStrategy: GridStrategy = {
      ...strategy,
      id,
      status: strategy.status || "active",
      currentPrice,
      totalPnL: 0,
      filledOrders: 0,
      totalOrders: strategy.gridLevels,
      gridUtilization: 0,
      createdAt: new Date()
    };
    
    this.gridStrategies.set(id, newStrategy);
    return newStrategy;
  }

  async updateGridStrategy(id: number, updates: Partial<GridStrategy>): Promise<GridStrategy | undefined> {
    const strategy = this.gridStrategies.get(id);
    if (!strategy) return undefined;
    
    const updatedStrategy = { ...strategy, ...updates };
    this.gridStrategies.set(id, updatedStrategy);
    return updatedStrategy;
  }

  async deleteGridStrategy(id: number): Promise<boolean> {
    return this.gridStrategies.delete(id);
  }

  async getTrades(gridStrategyId: number): Promise<Trade[]> {
    return Array.from(this.trades.values()).filter(
      trade => trade.gridStrategyId === gridStrategyId
    );
  }

  async createTrade(trade: InsertTrade): Promise<Trade> {
    const id = this.currentTradeId++;
    const newTrade: Trade = {
      ...trade,
      id,
      pnl: trade.pnl || 0,
      timestamp: new Date()
    };
    this.trades.set(id, newTrade);
    return newTrade;
  }

  async getRecentTrades(limit = 10): Promise<Trade[]> {
    return Array.from(this.trades.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }

  async getPortfolioStats(userId: number): Promise<PortfolioStats | undefined> {
    return this.portfolioStats.get(userId);
  }

  async updatePortfolioStats(userId: number, stats: Partial<PortfolioStats>): Promise<PortfolioStats> {
    const existing = this.portfolioStats.get(userId);
    const updated: PortfolioStats = {
      id: existing?.id || this.currentPortfolioId++,
      userId,
      totalBalance: 0,
      totalPnL: 0,
      todayPnL: 0,
      activePositions: 0,
      gridEfficiency: 0,
      lastUpdated: new Date(),
      ...existing,
      ...stats
    };
    
    this.portfolioStats.set(userId, updated);
    return updated;
  }

  async getMarketData(): Promise<MarketData[]> {
    return Array.from(this.marketData.values());
  }

  async updateMarketData(symbol: string, data: InsertMarketData): Promise<MarketData> {
    const existing = this.marketData.get(symbol);
    const updated: MarketData = {
      id: existing?.id || this.currentMarketId++,
      lastUpdated: new Date(),
      ...existing,
      ...data
    };
    
    this.marketData.set(symbol, updated);
    return updated;
  }
}

export const storage = new MemStorage();
