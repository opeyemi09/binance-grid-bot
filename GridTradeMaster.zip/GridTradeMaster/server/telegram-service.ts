import TelegramBot from 'node-telegram-bot-api';
import type { TelegramSettings, Trade, GridStrategy, PortfolioStats } from '@shared/schema';

export class TelegramService {
  private bot: TelegramBot | null = null;
  private settings: TelegramSettings | null = null;

  constructor() {
    this.initializeBot();
  }

  private initializeBot() {
    const token = process.env.TELEGRAM_BOT_TOKEN;
    
    if (token) {
      try {
        this.bot = new TelegramBot(token, { polling: false });
        console.log('Telegram bot initialized');
      } catch (error) {
        console.error('Failed to initialize Telegram bot:', error);
        this.bot = null;
      }
    } else {
      console.log('Telegram bot token not provided');
    }
  }

  updateSettings(settings: TelegramSettings) {
    this.settings = settings;
    
    // Re-initialize bot if token changed
    if (settings.botToken && settings.botToken !== process.env.TELEGRAM_BOT_TOKEN) {
      try {
        this.bot = new TelegramBot(settings.botToken, { polling: false });
        console.log('Telegram bot re-initialized with new token');
      } catch (error) {
        console.error('Failed to re-initialize Telegram bot:', error);
        this.bot = null;
      }
    }
  }

  private async sendMessage(message: string): Promise<boolean> {
    if (!this.bot || !this.settings?.chatId || !this.settings.alertsEnabled) {
      return false;
    }

    try {
      await this.bot.sendMessage(this.settings.chatId, message, {
        parse_mode: 'Markdown',
        disable_web_page_preview: true,
      });
      return true;
    } catch (error) {
      console.error('Failed to send Telegram message:', error);
      return false;
    }
  }

  async sendTradeAlert(trade: Trade, strategy: GridStrategy, accountBalance: number): Promise<boolean> {
    if (!this.settings?.tradeAlerts) {
      return false;
    }

    const emoji = trade.side === 'buy' ? '🟢' : '🔴';
    const action = trade.side.toUpperCase();
    const pnlText = trade.pnl > 0 ? `+$${trade.pnl.toFixed(2)}` : `$${trade.pnl.toFixed(2)}`;
    
    const message = `
${emoji} *Grid Trade Executed*

*Pair:* \`${trade.symbol}\`
*Action:* ${action}
*Price:* $${trade.price.toLocaleString()}
*Quantity:* ${trade.quantity.toFixed(6)}
*Amount:* $${trade.amount.toFixed(2)}
*P&L:* ${pnlText}

*Strategy Stats:*
• Grid Range: $${strategy.lowerPrice.toLocaleString()} - $${strategy.upperPrice.toLocaleString()}
• Total P&L: $${strategy.totalPnL.toFixed(2)}
• Filled Orders: ${strategy.filledOrders}/${strategy.totalOrders}
• Grid Utilization: ${strategy.gridUtilization.toFixed(1)}%

*Account Balance:* $${accountBalance.toLocaleString()}
    `.trim();

    return await this.sendMessage(message);
  }

  async sendProfitAlert(
    strategy: GridStrategy, 
    totalProfit: number, 
    accountBalance: number
  ): Promise<boolean> {
    if (!this.settings?.profitAlerts) {
      return false;
    }

    const profitEmoji = totalProfit > 0 ? '💰' : '📉';
    
    const message = `
${profitEmoji} *Grid Strategy Update*

*Pair:* \`${strategy.symbol}\`
*Total P&L:* $${totalProfit.toFixed(2)}
*Grid Efficiency:* ${strategy.gridUtilization.toFixed(1)}%
*Orders Filled:* ${strategy.filledOrders}/${strategy.totalOrders}

*Account Balance:* $${accountBalance.toLocaleString()}

*Grid Range:* $${strategy.lowerPrice.toLocaleString()} - $${strategy.upperPrice.toLocaleString()}
    `.trim();

    return await this.sendMessage(message);
  }

  async sendDailyReport(portfolioStats: PortfolioStats, strategies: GridStrategy[]): Promise<boolean> {
    if (!this.settings?.alertsEnabled) {
      return false;
    }

    const activeStrategies = strategies.filter(s => s.status === 'active');
    const totalInvestment = strategies.reduce((sum, s) => sum + s.investmentAmount, 0);
    const avgUtilization = strategies.reduce((sum, s) => sum + s.gridUtilization, 0) / strategies.length;

    const message = `
📊 *Daily Trading Report*

*Portfolio Overview:*
• Total Balance: $${portfolioStats.totalBalance.toLocaleString()}
• Today's P&L: $${portfolioStats.todayPnL.toFixed(2)}
• Total P&L: $${portfolioStats.totalPnL.toFixed(2)}

*Grid Performance:*
• Active Grids: ${activeStrategies.length}
• Total Investment: $${totalInvestment.toLocaleString()}
• Avg Grid Efficiency: ${avgUtilization.toFixed(1)}%

*Top Performers:*
${strategies
  .sort((a, b) => b.totalPnL - a.totalPnL)
  .slice(0, 3)
  .map(s => `• ${s.symbol}: $${s.totalPnL.toFixed(2)}`)
  .join('\n')}
    `.trim();

    return await this.sendMessage(message);
  }

  async sendGridStatusAlert(strategy: GridStrategy, status: 'started' | 'paused' | 'stopped'): Promise<boolean> {
    if (!this.settings?.alertsEnabled) {
      return false;
    }

    const statusEmojis = {
      started: '🚀',
      paused: '⏸️',
      stopped: '🛑'
    };

    const message = `
${statusEmojis[status]} *Grid Strategy ${status.charAt(0).toUpperCase() + status.slice(1)}*

*Pair:* \`${strategy.symbol}\`
*Investment:* $${strategy.investmentAmount.toLocaleString()}
*Grid Range:* $${strategy.lowerPrice.toLocaleString()} - $${strategy.upperPrice.toLocaleString()}
*Grid Levels:* ${strategy.gridLevels}
*Current P&L:* $${strategy.totalPnL.toFixed(2)}
    `.trim();

    return await this.sendMessage(message);
  }

  async testConnection(): Promise<boolean> {
    if (!this.bot || !this.settings?.chatId) {
      return false;
    }

    try {
      await this.bot.sendMessage(
        this.settings.chatId,
        '✅ *GridBot Pro Connected*\n\nTelegram alerts are now active!',
        { parse_mode: 'Markdown' }
      );
      return true;
    } catch (error) {
      console.error('Telegram connection test failed:', error);
      return false;
    }
  }

  isConnected(): boolean {
    return this.bot !== null && this.settings !== null;
  }
}

export const telegramService = new TelegramService();