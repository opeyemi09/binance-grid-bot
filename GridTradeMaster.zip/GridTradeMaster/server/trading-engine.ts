import { IStorage } from "./storage";
import { FileStorage } from "./file-storage";
import { binanceService } from "./binance-service";
import { telegramService } from "./telegram-service";
import type { GridStrategy, Trade, InsertTrade, MarketData } from "@shared/schema";

export class TradingEngine {
  private storage: IStorage;
  private fileStorage: FileStorage;
  private strategies: Map<number, GridStrategy> = new Map();
  private marketPrices: Map<string, number> = new Map();
  private intervals: Map<number, NodeJS.Timeout> = new Map();
  private marketInterval?: NodeJS.Timeout;
  private broadcastFn?: (data: any) => void;

  constructor(storage: IStorage, fileStorage: FileStorage) {
    this.storage = storage;
    this.fileStorage = fileStorage;
  }

  async start(broadcastFn: (data: any) => void) {
    this.broadcastFn = broadcastFn;
    
    // Load existing strategies
    const allStrategies = await this.storage.getGridStrategies(1); // Default user
    allStrategies.forEach(strategy => {
      if (strategy.status === 'active') {
        this.addStrategy(strategy);
      }
    });

    // Start real market data if Binance is connected, otherwise use simulation
    if (binanceService.isApiConnected()) {
      console.log('Starting real Binance market data streams...');
      this.startRealMarketData();
    } else {
      console.log('Binance API not connected, using simulated market data...');
      this.startMarketDataSimulation();
    }
    
    console.log('Trading engine started');
  }

  addStrategy(strategy: GridStrategy) {
    this.strategies.set(strategy.id, strategy);
    this.startStrategyExecution(strategy);
    console.log(`Added strategy ${strategy.id} for ${strategy.symbol}`);
  }

  removeStrategy(strategyId: number) {
    const interval = this.intervals.get(strategyId);
    if (interval) {
      clearInterval(interval);
      this.intervals.delete(strategyId);
    }
    this.strategies.delete(strategyId);
    console.log(`Removed strategy ${strategyId}`);
  }

  private startStrategyExecution(strategy: GridStrategy) {
    // Execute grid trading logic every 5 seconds
    const interval = setInterval(async () => {
      await this.executeGridLogic(strategy);
    }, 5000);
    
    this.intervals.set(strategy.id, interval);
  }

  private async executeGridLogic(strategy: GridStrategy) {
    try {
      const currentPrice = this.marketPrices.get(strategy.symbol) || strategy.currentPrice;
      const priceRange = strategy.upperPrice - strategy.lowerPrice;
      const gridStep = priceRange / strategy.gridLevels;
      
      // Update current price
      strategy.currentPrice = currentPrice;
      
      // Simulate grid trading logic
      const shouldTrade = Math.random() < 0.3; // 30% chance to execute a trade
      
      if (shouldTrade && strategy.filledOrders < strategy.totalOrders) {
        const side = Math.random() < 0.5 ? 'buy' : 'sell';
        const quantity = this.calculateTradeQuantity(strategy, currentPrice);
        const amount = quantity * currentPrice;
        
        // Calculate PnL (simplified)
        const pnl = side === 'sell' ? amount * 0.001 : 0; // 0.1% profit on sells
        
        const trade: InsertTrade = {
          gridStrategyId: strategy.id,
          symbol: strategy.symbol,
          side,
          price: currentPrice,
          quantity,
          amount,
          pnl
        };
        
        // Save trade
        const savedTrade = await this.storage.createTrade(trade);
        await this.fileStorage.saveTrade(trade);
        
        // Update strategy stats
        strategy.filledOrders += 1;
        strategy.totalPnL += pnl;
        strategy.gridUtilization = (strategy.filledOrders / strategy.totalOrders) * 100;
        
        await this.storage.updateGridStrategy(strategy.id, {
          currentPrice: strategy.currentPrice,
          filledOrders: strategy.filledOrders,
          totalPnL: strategy.totalPnL,
          gridUtilization: strategy.gridUtilization
        });
        
        // Send Telegram alert
        const portfolioStats = await this.storage.getPortfolioStats(1);
        if (portfolioStats) {
          await telegramService.sendTradeAlert(savedTrade, strategy, portfolioStats.totalBalance);
        }

        // Save orders and profits to JSON file
        await this.saveOrdersAndProfitsToFile();
        
        // Broadcast trade update
        this.broadcastFn?.({
          type: 'trade_executed',
          data: {
            strategy: strategy,
            trade: savedTrade
          }
        });
        
        console.log(`Executed ${side} trade for ${strategy.symbol} at $${currentPrice}`);
      }
      
      // Update strategy in storage
      await this.storage.updateGridStrategy(strategy.id, {
        currentPrice: strategy.currentPrice
      });
      
    } catch (error) {
      console.error(`Error executing grid logic for strategy ${strategy.id}:`, error);
    }
  }

  private calculateTradeQuantity(strategy: GridStrategy, currentPrice: number): number {
    // Calculate quantity based on investment amount and grid levels
    const investmentPerLevel = strategy.investmentAmount / strategy.gridLevels;
    return investmentPerLevel / currentPrice;
  }

  private startRealMarketData() {
    // Use Binance WebSocket streams for real-time data
    const symbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'ADAUSDT'];
    
    binanceService.startPriceStream(symbols, async (data) => {
      const symbolFormatted = `${data.symbol.slice(0, -4)}/${data.symbol.slice(-4)}`;
      
      await this.storage.updateMarketData(symbolFormatted, {
        symbol: symbolFormatted,
        price: data.price,
        change24h: data.change,
        volume: data.volume,
      });
      
      this.marketPrices.set(symbolFormatted, data.price);
      
      // Broadcast market update
      this.broadcastFn?.({
        type: 'market_update',
        data: await this.storage.getMarketData()
      });
    });
    
    // Update portfolio stats every 5 seconds
    this.marketInterval = setInterval(async () => {
      await this.updatePortfolioStats();
    }, 5000);
  }

  private startMarketDataSimulation() {
    // Update market prices every 2 seconds
    this.marketInterval = setInterval(async () => {
      await this.updateMarketPrices();
    }, 2000);
  }

  private async updateMarketPrices() {
    try {
      const marketData = await this.storage.getMarketData();
      
      for (const market of marketData) {
        // Simulate price movement (±0.5% random walk)
        const change = (Math.random() - 0.5) * 0.01; // ±0.5%
        const newPrice = market.price * (1 + change);
        const newChange24h = market.change24h + change * 100;
        
        // Update market data
        await this.storage.updateMarketData(market.symbol, {
          symbol: market.symbol,
          price: newPrice,
          change24h: newChange24h,
          volume: market.volume
        });
        
        this.marketPrices.set(market.symbol, newPrice);
      }
      
      // Broadcast market update
      this.broadcastFn?.({
        type: 'market_update',
        data: await this.storage.getMarketData()
      });
      
      // Update portfolio stats
      await this.updatePortfolioStats();
      
    } catch (error) {
      console.error('Error updating market prices:', error);
    }
  }

  private async updatePortfolioStats() {
    try {
      const strategies = Array.from(this.strategies.values());
      const totalPnL = strategies.reduce((sum, strategy) => sum + strategy.totalPnL, 0);
      const activePositions = strategies.filter(s => s.status === 'active').length;
      const avgUtilization = strategies.reduce((sum, s) => sum + s.gridUtilization, 0) / strategies.length;
      
      const stats = {
        totalBalance: 45823.67 + totalPnL,
        totalPnL,
        todayPnL: totalPnL * 0.2, // Assume 20% of total PnL is from today
        activePositions,
        gridEfficiency: avgUtilization || 87.3,
        lastUpdated: new Date()
      };
      
      await this.storage.updatePortfolioStats(1, stats);
      
      // Broadcast portfolio update
      this.broadcastFn?.({
        type: 'portfolio_update',
        data: stats
      });
      
    } catch (error) {
      console.error('Error updating portfolio stats:', error);
    }
  }

  private async saveOrdersAndProfitsToFile() {
    try {
      const allTrades = await this.storage.getRecentTrades(1000);
      const allStrategies = Array.from(this.strategies.values());
      
      const profits: { [symbol: string]: number } = {};
      let totalProfit = 0;

      allStrategies.forEach(strategy => {
        profits[strategy.symbol] = strategy.totalPnL;
        totalProfit += strategy.totalPnL;
      });

      const data = {
        orders: allTrades,
        profits,
        totalProfit,
        timestamp: new Date().toISOString(),
        accountBalance: 45823.67 + totalProfit,
      };

      await this.fileStorage.saveOrdersAndProfits(data);
    } catch (error) {
      console.error('Error saving orders and profits to file:', error);
    }
  }

  stop() {
    // Clear all intervals
    this.intervals.forEach(interval => clearInterval(interval));
    this.intervals.clear();
    
    if (this.marketInterval) {
      clearInterval(this.marketInterval);
    }
    
    console.log('Trading engine stopped');
  }
}
