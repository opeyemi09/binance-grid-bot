import { pgTable, text, serial, integer, boolean, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const gridStrategies = pgTable("grid_strategies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  symbol: text("symbol").notNull(), // BTC/USDT, ETH/USDT, etc.
  status: text("status").notNull().default("active"), // active, paused, stopped
  lowerPrice: real("lower_price").notNull(),
  upperPrice: real("upper_price").notNull(),
  gridLevels: integer("grid_levels").notNull(),
  investmentAmount: real("investment_amount").notNull(),
  currentPrice: real("current_price").notNull(),
  totalPnL: real("total_pnl").notNull().default(0),
  filledOrders: integer("filled_orders").notNull().default(0),
  totalOrders: integer("total_orders").notNull(),
  gridUtilization: real("grid_utilization").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const trades = pgTable("trades", {
  id: serial("id").primaryKey(),
  gridStrategyId: integer("grid_strategy_id").notNull(),
  symbol: text("symbol").notNull(),
  side: text("side").notNull(), // buy, sell
  price: real("price").notNull(),
  quantity: real("quantity").notNull(),
  amount: real("amount").notNull(),
  pnl: real("pnl").notNull().default(0),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const portfolioStats = pgTable("portfolio_stats", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  totalBalance: real("total_balance").notNull(),
  totalPnL: real("total_pnl").notNull(),
  todayPnL: real("today_pnl").notNull(),
  activePositions: integer("active_positions").notNull(),
  gridEfficiency: real("grid_efficiency").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const marketData = pgTable("market_data", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull().unique(),
  price: real("price").notNull(),
  change24h: real("change_24h").notNull(),
  volume: real("volume").notNull(),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const candlestickData = pgTable("candlestick_data", {
  id: serial("id").primaryKey(),
  symbol: text("symbol").notNull(),
  open: real("open").notNull(),
  high: real("high").notNull(),
  low: real("low").notNull(),
  close: real("close").notNull(),
  volume: real("volume").notNull(),
  timestamp: timestamp("timestamp").notNull(),
});

export const telegramSettings = pgTable("telegram_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  botToken: text("bot_token"),
  chatId: text("chat_id"),
  alertsEnabled: boolean("alerts_enabled").notNull().default(true),
  tradeAlerts: boolean("trade_alerts").notNull().default(true),
  profitAlerts: boolean("profit_alerts").notNull().default(true),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertGridStrategySchema = createInsertSchema(gridStrategies).omit({
  id: true,
  userId: true,
  currentPrice: true,
  totalPnL: true,
  filledOrders: true,
  gridUtilization: true,
  createdAt: true,
});

export const insertTradeSchema = createInsertSchema(trades).omit({
  id: true,
  timestamp: true,
});

export const insertMarketDataSchema = createInsertSchema(marketData).omit({
  id: true,
  lastUpdated: true,
});

export const insertCandlestickDataSchema = createInsertSchema(candlestickData).omit({
  id: true,
});

export const insertTelegramSettingsSchema = createInsertSchema(telegramSettings).omit({
  id: true,
  userId: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type GridStrategy = typeof gridStrategies.$inferSelect;
export type InsertGridStrategy = z.infer<typeof insertGridStrategySchema>;
export type Trade = typeof trades.$inferSelect;
export type InsertTrade = z.infer<typeof insertTradeSchema>;
export type PortfolioStats = typeof portfolioStats.$inferSelect;
export type MarketData = typeof marketData.$inferSelect;
export type InsertMarketData = z.infer<typeof insertMarketDataSchema>;
export type CandlestickData = typeof candlestickData.$inferSelect;
export type InsertCandlestickData = z.infer<typeof insertCandlestickDataSchema>;
export type TelegramSettings = typeof telegramSettings.$inferSelect;
export type InsertTelegramSettings = z.infer<typeof insertTelegramSettingsSchema>;
